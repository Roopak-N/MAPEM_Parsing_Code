#ifndef ITS_OB4_M_EXCEPTION_H
#define ITS_OB4_M_EXCEPTION_H

#include <exception>
#include <string>
#include <cms_v2x/api.h>


namespace ItsRs4M
{
    class ItsRs4M_exception : public std::exception
    {
    public:
        ItsRs4M_exception();
        ItsRs4M_exception(const std::string &message);
        ItsRs4M_exception(const std::string &message, bool err);

        const char *what() const noexcept override;

    private:
        std::string m_message;
        bool m_err;
    };
} // namespace ItsRs4M


#endif // ITS_OB4_M_EXCEPTION_H
