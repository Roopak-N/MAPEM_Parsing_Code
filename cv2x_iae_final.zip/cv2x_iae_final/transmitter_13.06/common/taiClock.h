#include "clock.hpp"
#include <chrono>
#include <cstdint>

namespace cv2x
{


struct TaiClock
{
    using rep = int64_t;
    using period = std::micro; /*< microsecond ticks */
    using duration = std::chrono::duration<rep, period>;
    using time_point = std::chrono::time_point<TaiClock>;

    /**
     * CLOCK_TAI is not affected by discontinuous jumps of system time (UTC).
     * Kernel's TAI offset may get adjusted during runtime -> CLOCK_TAI is not steady
     */
    static constexpr bool is_steady() { return false; }

    /**
     * Return current TAI time point.
     * This may throw an exception if CLOCK_TAI is unavailable.
     * \return TAI time point
     */
    static time_point now();

    /**
     * Check if TAI clock is sychronized, i.e. local clock is stabilized and TAI offset is set
     * \return true if sychronized
     */
    static bool synchronized();
};

template<class ToClock, class FromTimePoint>
typename ToClock::time_point time_point_cast(FromTimePoint);

template<>
vanetza::Clock::time_point time_point_cast<vanetza::Clock>(TaiClock::time_point);

template<>
TaiClock::time_point time_point_cast<TaiClock>(vanetza::Clock::time_point);

} 