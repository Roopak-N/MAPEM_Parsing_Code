#include "logger.h"

#include <iostream>
#include <cms_v2x/api.h>

void Logger::logInfo(const std::string &message)
{
    std::cout << "[I] " << message << std::endl;
}

void Logger::logError(const std::string &message)
{
    std::cerr << "[ERROR] " << message << std::endl;
}

void Logger::logError(const std::string &message, bool err)
{
    // std::cerr << "[ERROR] " << message << ": " << v2x_get_err_str(err) << std::endl;
}

void Logger::logShutdown(int signal_number)
{
    std::cout << "[SHUTDOWN] Received signal " << signal_number << std::endl;
}
