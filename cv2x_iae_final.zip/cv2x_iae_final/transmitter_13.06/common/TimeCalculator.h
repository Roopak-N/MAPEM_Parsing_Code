#include <iostream>
#include <chrono>

using namespace std;

namespace V2XTimeStamps
{
class TimeCalculator
{
    private:

    public:

    int convertGpsFixToGenDelta(int64_t);
    int objectTimeOfMeasurementFromSdf();
};
}