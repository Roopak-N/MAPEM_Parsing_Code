#include "TimeCalculator.h"


/*Takes the GPS timestamp in milliseconds as input and provides the generation delta time*/
int V2XTimeStamps::TimeCalculator::convertGpsFixToGenDelta(int64_t last_gps_fix_time)
{
printf("Calculating Generation delta time with reference to last GPS fix \n");

//taking the last GPS fix time (in ms), we calculate the number of milliseconds that have passed since the ISO 8601 time reference - 2004-01-01T00:00:00:000Z
 std::chrono::time_point<std::chrono::system_clock> baseTimestamp = std::chrono::time_point<std::chrono::system_clock>(std::chrono::milliseconds(0));
printf("base time stamp %ld \n",baseTimestamp);
    // Get the current time from Linux system clock
std::chrono::time_point<std::chrono::system_clock> currentTimestamp = std::chrono::system_clock::now();
printf("Current time stamp provided by GPS %ld \n",last_gps_fix_time);
printf("Current time stamp  %ld \n",currentTimestamp);

    // Compute the number of milliseconds since the base timestamp
std::chrono::milliseconds timestampIts = std::chrono::duration_cast<std::chrono::milliseconds>(currentTimestamp-baseTimestamp);
printf("Current time stamp ITS %ld \n",timestampIts);
    // Compute generationDeltaTime
    //int generationDeltaTime = last_gps_fix_time.count() % 65536;
return 0;
}

/*Takes the timestamp from sensor data fusion as input and provides object time of measurement for CAM/CPm according to ETSI TR 103562*/
int V2XTimeStamps::TimeCalculator::objectTimeOfMeasurementFromSdf()
{

}
