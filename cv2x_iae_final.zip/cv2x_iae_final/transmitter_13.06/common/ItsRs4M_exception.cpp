#include "ItsRs4M_exception.h"

ItsRs4M::ItsRs4M_exception::ItsRs4M_exception()
{
}

ItsRs4M::ItsRs4M_exception::ItsRs4M_exception(const std::string &message)
    : m_message(message)
{
}

ItsRs4M::ItsRs4M_exception::ItsRs4M_exception(const std::string &message, bool err)
    : m_message(message)
    , m_err(err)
{
}

const char *ItsRs4M::ItsRs4M_exception::what() const noexcept
{
    //std::string err_msg = m_message + ": " + v2x_get_err_str(m_err);
    //return err_msg.c_str();
    return "";
}

