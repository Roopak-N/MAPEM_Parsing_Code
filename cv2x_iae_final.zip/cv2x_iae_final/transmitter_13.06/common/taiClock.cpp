#include "taiClock.h"
#include <stdexcept>
#include <time.h>
#include <sys/timex.h> /* < only available on Linux */

namespace cv2x
{

namespace {

// POSIX seconds representing 2004-01-01 (UTC)
static const auto its_epoch_posix = std::chrono::seconds(1072915200);

} // namespace

TaiClock::time_point TaiClock::now()
{
    using scale_second = std::ratio_divide<std::ratio<1>, period>;
    using scale_nanosecond = std::ratio_divide<std::nano, period>;

    timespec now;
    if (clock_gettime(CLOCK_TAI, &now) == 0) {
        // TaiClock uses microsecond ticks
        TaiClock::rep ticks = 0;
        ticks = now.tv_sec * scale_second::num / scale_second::den;
        ticks += now.tv_nsec * scale_nanosecond::num / scale_nanosecond::den;
        printf("TAI clock function %ld \n",TaiClock::time_point(duration(ticks)));
        return TaiClock::time_point(duration(ticks));
    } else {
        throw std::runtime_error("reading CLOCK_TAI failed");
    }
}

bool TaiClock::synchronized()
{
    timex ntx;
    ntx.modes = 0;
    if (adjtimex(&ntx) == TIME_ERROR) {
        return false;
    } else {
        return ntx.tai != 0;
    }
}

template<>
vanetza::Clock::time_point time_point_cast<vanetza::Clock>(TaiClock::time_point tai)
{
    // TAI duration since POSIX epoch (1970-01-01 UTC)
    auto tai_since_epoch = tai.time_since_epoch();
    return vanetza::Clock::time_point { tai_since_epoch - its_epoch_posix };
}

template<>
TaiClock::time_point time_point_cast<TaiClock>(vanetza::Clock::time_point its)
{
    // TAI duration since ITS epoch (2004-01-01 UTC)
    auto its_since_epoch = its.time_since_epoch();
    return TaiClock::time_point { its_since_epoch + its_epoch_posix };
}

} 