#ifndef LOGGER_H
#define LOGGER_H

#include <string>
#include <cms_v2x/api.h>

namespace Logger
{
    void logInfo(const std::string &message);
    void logError(const std::string &message);
    void logError(const std::string &message, bool err);
    void logShutdown(int signal_number);
} // namespace namespace

#endif // LOGGER_H
