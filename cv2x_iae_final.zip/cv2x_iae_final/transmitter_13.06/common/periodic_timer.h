#ifndef PERIODIC_TIMER_H
#define PERIODIC_TIMER_H

#include <boost/asio/io_context.hpp>
#include <boost/asio/steady_timer.hpp>

#include <boost/signals2/signal.hpp>

#include <chrono>

class PeriodicTimer
{
public:
    PeriodicTimer(boost::asio::io_context &ctx, uint interval_ms);
    ~PeriodicTimer();

    void start();
    void stop();

    // signals
    boost::signals2::signal<void()> sig_timeout;

protected:
    void handleTimeout(const boost::system::error_code &err);

private:
    uint m_interval_ms;
    boost::asio::steady_timer m_timer;
};

#endif // PERIODIC_TIMER_H