

#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>

#include <cms_v2x/api.h>
#include <v2x/asn.1/v2x_eu_asn.h>
#include <cms_v2x/gn.h>
#include <v2x/asn.1/asn1defs.h>


#define LANE_WEST_INGRESS_START_LAT            389169770
#define LANE_WEST_INGRESS_START_LON            -770122820
#define LANE_WEST_INGRESS_END_LAT              389169810
#define LANE_WEST_INGRESS_END_LON              -770126280

/** @file
@brief Send an EU MAP message.
@ingroup ex
*/

static void create_and_send_a_map(const cms_session_t* session);
static void print_xml(const EU_MAPEM* map);
static bool send_as_geonet_message(const cms_session_t* session, cms_buffer_view_t msg);
static void fill_gnp_header(cms_gn_send_data_t* header);


static void fill_map(EU_MAPEM* mapem) {

    EU_ItsPduHeader* header1 = &mapem->header;
    header1->protocolVersion = 2;
    header1->messageID = 5;
    header1->stationID = 2;

    EU_MapData* map = &mapem->map;

    map->dataParameters_option = false;
    map->intersections_option = true;
    map->layerID_option = false;
    map->layerType_option = true;
    map->layerType = EU_LayerType_intersectionData;
    map->restrictionList_option = false;
    map->timeStamp_option = false;
    map->roadSegments_option = false;
    map->msgIssueRevision = 2;

    map->intersections.count = 0;

    EU_IntersectionGeometry intersection = {};
    intersection.id.id = 13;
    intersection.speedLimits_option = false;
    intersection.id.region_option = false;
    intersection.laneWidth_option = false;
    intersection.name_option = false;
    intersection.preemptPriorityData_option = false;
    intersection.regional_option = false;
    intersection.revision = 1;    

    /* Add reference point */
    intersection.refPoint.lat = LANE_WEST_INGRESS_START_LAT;
    intersection.refPoint.Long = LANE_WEST_INGRESS_START_LON;
    intersection.refPoint.elevation_option = false;
    intersection.refPoint.regional_option = false;

    intersection.laneSet.count = 0;

    uint8_t buffer[1] = {0x00};

    /* Create an ingress lane */
    EU_GenericLane lane = {};
    lane.connectsTo_option = false;
    lane.egressApproach_option = false;
    lane.ingressApproach_option = true;
    lane.ingressApproach = 1;
    lane.laneAttributes.regional_option = false;
    lane.laneAttributes.laneType.choice =  EU_LaneTypeAttributes_vehicle;
    lane.laneAttributes.laneType.u.vehicle.len = 2;
    lane.laneAttributes.laneType.u.vehicle.buf = buffer;
    lane.laneAttributes.directionalUse.len = 2;
    lane.laneAttributes.directionalUse.buf = buffer;
    lane.laneAttributes.sharedWith.len = 10;
    lane.laneAttributes.sharedWith.buf = buffer;
    lane.laneID = 1;
    lane.maneuvers_option = false;
    lane.name_option = false;
    lane.overlays_option = false;
    lane.regional_option = false;
    lane.nodeList.choice =  EU_NodeListXY_nodes;
    lane.nodeList.u.nodes.count = 0;

    /* Create nodes */ 
    EU_NodeXY node1 = {};
    node1.attributes_option = false;
    node1.delta.choice = EU_NodeOffsetPointXY_node_LatLon;
    node1.delta.u.node_LatLon.lat = LANE_WEST_INGRESS_START_LAT;
    node1.delta.u.node_LatLon.lon = LANE_WEST_INGRESS_START_LON;

    EU_NodeXY node2 = {};
    node2.attributes_option = false;
    node2.delta.choice = EU_NodeOffsetPointXY_node_LatLon;
    node2.delta.u.node_LatLon.lat = LANE_WEST_INGRESS_END_LAT;
    node2.delta.u.node_LatLon.lon = LANE_WEST_INGRESS_END_LON;

    /*Add nodes to lane*/
    if(asn1_seq_add(asn1_type_EU_NodeXY,
                    &lane.nodeList.u.nodes.count,
                    (void**)(&lane.nodeList.u.nodes.tab),
                    &node1)) {
        printf("Unable to add seq\n");
    };
    
    if(asn1_seq_add(asn1_type_EU_NodeXY,
                    &lane.nodeList.u.nodes.count,
                    (void**)(&lane.nodeList.u.nodes.tab),
                    &node2)) {
        printf("Unable to add seq\n");
    };

    /*Add lane to intersection*/
     if(asn1_seq_add(asn1_type_EU_GenericLane,
                    &intersection.laneSet.count,
                    (void**)(&intersection.laneSet.tab),
                    &lane)) {
        printf("Unable to add seq\n");
    };

    /*Add intersection to IntersectionList */
    if(asn1_seq_add(asn1_type_EU_IntersectionGeometry,
                    &map->intersections.count,
                    (void**)(&map->intersections.tab),
                    &intersection)) {
        printf("Unable to add seq\n");
    };

}

static void create_and_send_a_map(const cms_session_t* session)
{
    bool error = false;
    ASN1Error decode_err = {0};
    EU_MAPEM mapem = {0};
    fill_map(&mapem);

    if(!error) {
        /* Print MAPEM */
        print_xml(&mapem);
    }
    
    if(!error) {
        /* Encode to an allocated buffer */
        uint8_t* encode_buff = NULL;
        int encoded_length = asn1_uper_encode2(&encode_buff, asn1_type_EU_MAPEM, &mapem, &decode_err);
        if(encoded_length <= 0) {
            printf("Error in encode: %s\n", decode_err.msg);
            error = true;
        } else {

            cms_buffer_view_t msg = {
                .data = encode_buff,
                .length = encoded_length
            };
            /*Send as a WSMP message */
            error = send_as_geonet_message(session, msg);
        }
    }

}


/* Print message as XML with encoding to XER */
static void print_xml(const EU_MAPEM* map)
{
    uint8_t* xer_buff = NULL;
    int xer_len = asn1_xer_encode(&xer_buff, asn1_type_EU_MAPEM, map);
    if(xer_len <= 0) {
        printf("Error in xer encode\n");
    } else {
        printf("%.*s\n", xer_len, xer_buff);
    }

    if(xer_buff != NULL) {
        asn1_free(xer_buff);
    }
}


/* Send a GeoNetworking message */
static bool send_as_geonet_message(const cms_session_t* session, cms_buffer_view_t msg)
{

    cms_gn_send_data_t gnp_hdr = {0};
    fill_gnp_header(&gnp_hdr);

    bool error = cms_gn_send(session, &gnp_hdr, msg, NULL);
    if(error) {
        printf("Unable to send GeoNet message\n");
    } else {
        printf("GeoNet message sent\n");
    }

    return error;
}


/* Fill GeoNetworking parameters */
static void fill_gnp_header(cms_gn_send_data_t* header)
{
    /* Radio parameters */
    header->radio.datarate = CMS_DATARATE_NA;
    header->radio.expiry_time = 1000U;
    header->radio.interface_id = 1U;
    header->radio.sps_index = CMS_SPS_CHANNEL_INDEX_NA;
    header->radio.tx_power = 20;
    header->radio.user_prio = CMS_MAC_USER_PRIO_NA;

    /* GeoNet parameters - BTP for MAP */
    header->gn_params.btp_params.btp_port = 2003U;
    header->gn_params.btp_params.dest_port_info = 0U;

    /* GeoNet parameters - GeoNet header  */
    header->gn_params.gn_hdr.lifetime_ms = 60000U;
    header->gn_params.gn_hdr.max_hop_limit = 1;
    header->gn_params.gn_hdr.method = CMS_GN_SEND_METHOD_SHB;

    /* GeoNet parameters - GeoNet header  - Traffic class */
    header->gn_params.gn_hdr.traffic_class.chf_offl = CMS_GN_TRAFFIC_CLASS_CHF_OFFL_DISABLE;
    header->gn_params.gn_hdr.traffic_class.scf_en = CMS_GN_TRAFFIC_CLASS_SCF_DISABLE;
    header->gn_params.gn_hdr.traffic_class.tcid = 0U;

    /* Security info */
    header->security.sign_info.psid = 0U;
    header->security.sign_info.sign_method = CMS_SIGN_METH_NONE;
    header->security.sign_info.ssp.length = 0U;
    /* Keep header->security.ssp.ssp_field zeroed */
}



int main(int argc, char* argv[])
{
    const char* host = (argc > 1) ? argv[1] : "192.168.1.54";

    /* Create a session */
    cms_session_t session = cms_get_session();

    /* Connect to the host */
    bool error = cms_api_connect_easy(&session, host);

    /* Send a SPAT */
    if(!error) {
        create_and_send_a_map(&session);
    }

    /* Close connection */
    cms_api_disconnect(&session); 
    cms_api_clean();

    return (int)error;
}
