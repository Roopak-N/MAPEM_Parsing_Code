#include "MapWriter.h"
#include "logger.h"
#include "periodic_timer.h"
#include <chrono>
using namespace std::chrono;

MapWriter::MapWriter(cms_session_t session)
    : m_workGuard(boost::asio::make_work_guard(m_ev)), m_session(session)
{
    cms_nav_get_last_fix(&m_session, NULL, &nav_fix);
}

MapWriter::~MapWriter()
{
    stop();
}

void MapWriter::start()
{
    if (m_MapWriterThread)
    {
        return;
    }
    m_MapWriterThread = new std::thread([this]()
                                        {
        PeriodicTimer timer(m_ev, 1000);
        timer.start();
        timer.sig_timeout.connect([this]() {
            printf("MapWriter::start");
           create_and_send_a_map(& m_session);      
        
        });

        m_ev.run(); });
}

void MapWriter::stop()
{
    /* Sleep for 1 second */
    /* Keep alive */
    for (;;)
    {
        (void)sleep(10);
    }
    if (m_MapWriterThread)
    {
        m_workGuard.reset();
        m_ev.stop();
        m_MapWriterThread->join();
        delete m_MapWriterThread;
        m_MapWriterThread = nullptr;
    }
}

// Parsing json
void MapWriter::parseJSON(const json &data, std::map<std::string, std::string> &keyValuePairs, const std::string &prefix = "")
{
    if (data.is_object())
    {
        for (auto it = data.begin(); it != data.end(); ++it)
        {
            // Generate the key by appending the current level's key to the prefix
            std::string key = prefix.empty() ? it.key() : prefix + "." + it.key();

            // Recursively call the function for nested objects or arrays
            if (it.value().is_object() || it.value().is_array())
            {
                parseJSON(it.value(), keyValuePairs, key);
            }
            else
            {
                // Store the key-value pair in the map
                keyValuePairs[key] = it.value().dump();
            }
        }
    }
    else if (data.is_array())
    {
        for (size_t i = 0; i < data.size(); ++i)
        {
            std::string key = prefix + "[" + std::to_string(i) + "]";

            if (data[i].is_object() || data[i].is_array())
            {
                parseJSON(data[i], keyValuePairs, key);
            }
            else
            {
                keyValuePairs[key] = data[i].dump();
            }
        }
    }
}

void MapWriter::parseJSONFile(const std::string &filename, std::map<std::string, std::string> &keyValuePairs)
{

    std::ifstream file(filename);
    if (!file.is_open())
    {
        std::cout << "Failed to open the JSON file." << std::endl;
        return;
    }

    try
    {
        json jsonData;
        file >> jsonData;

        parseJSON(jsonData, keyValuePairs);
    }

    catch (const json::exception &e)
    {
        std::cout << "Error while parsing JSON: " << e.what() << std::endl;
    }

    file.close();
}

// Fill the contents of CPM

void MapWriter::fill_map(EU_MAP *mapem, std::map<std::string, std::string> &keyValuePairs)
{
    printf("Filling the contents of MAPem \n");

    // Parse Json file from group 2
    parseJSONFile("ISD_11090_RSU#05_MAPEM_StringModified.json", keyValuePairs);

    EU_ItsPduHeader *header = &mapem->header;
    header->protocolVersion = 2;
    header->messageID = 5;
    header->stationID = 2;

    EU_MapData *map = &mapem->map;

    map->dataParameters_option = false;
    map->intersections_option = true;
    map->layerID_option = std::stoi(keyValuePairs.at("mapData.intersectionGeometry.referencePoint.layerID"));
    map->layerType_option = true;
    map->layerType = static_cast<EU_LayerType>(std::stoi(keyValuePairs.at("mapData.layerType")));
    map->restrictionList_option = false;
    map->timeStamp_option = std::stoi(keyValuePairs.at("mapData.minuteOfTheYear"));
    map->roadSegments_option = false;
    map->msgIssueRevision = false;

    map->intersections.count = 0;
    uint8_t buffer[1] = {0x00};

    // Iterate over the intersections
    for (int intersectionIndex = 0;; ++intersectionIndex)
    {
        std::string intersectionKeyPrefix = "intersection." + std::to_string(intersectionIndex) + ".";
        if (keyValuePairs.count(intersectionKeyPrefix + "id") == 0)
            break; // No more intersections found, exit the loop

        intersection.id.id = std::stoi(keyValuePairs.at(intersectionKeyPrefix + "id"));
        intersection.speedLimits_option = std::stod(keyValuePairs.at(intersectionKeyPrefix + "speedLimits"));
        intersection.id.region_option = false;
        intersection.laneWidth_option = std::stod(keyValuePairs.at(intersectionKeyPrefix + "laneWidth"));
        intersection.name_option = !keyValuePairs.at(intersectionKeyPrefix + "descriptiveIntersectionName").empty();
        intersection.preemptPriorityData_option = false;
        intersection.regional_option = false;
        intersection.revision = false;

        // Add reference point

        refPoint.lat = std::stod(keyValuePairs.at(intersectionKeyPrefix + "referencePoint.referenceLat"));
        refPoint.Long = std::stod(keyValuePairs.at(intersectionKeyPrefix + "referencePoint.referenceLon"));
        refPoint.elevation_option = std::stod(keyValuePairs.at(intersectionKeyPrefix + "referencePoint.referenceElevation"));
        refPoint.regional_option = false;
        intersection.refPoint = refPoint;

        intersection.laneSet.count = std::stoi(keyValuePairs.at(intersectionKeyPrefix + "laneSet.count"));

        // Iterate over the lanes for the current intersection
        for (int laneIndex = 0; laneIndex < intersection.laneSet.count; ++laneIndex)
        {
            std::string laneKeyPrefix = intersectionKeyPrefix + "laneSet." + std::to_string(laneIndex) + ".";
            std::string approachType = keyValuePairs.at(laneKeyPrefix + "approachType");
            if (approachType == "Ingress")
            {
                lane.ingressApproach_option = true;
                lane.ingressApproach = std::stoi(keyValuePairs.at(laneKeyPrefix + "ingressApproach"));
                int approachID = std::stoi(keyValuePairs.at(laneKeyPrefix + "approachID"));
                lane.ingressApproach = approachID;
            }
            else if (approachType == "Egress")
            {
                lane.egressApproach_option = true;
                lane.egressApproach = std::stoi(keyValuePairs.at(laneKeyPrefix + "egressApproach"));
                int approachID = std::stoi(keyValuePairs.at(laneKeyPrefix + "approachID"));
                lane.egressApproach = approachID;
            }
            
            lane.connectsTo_option = false;
            lane.laneAttributes.regional_option = false;
            lane.laneAttributes.laneType.choice = EU_LaneTypeAttributes_vehicle;
            lane.laneAttributes.laneType.u.vehicle.len = std::stoi(keyValuePairs.at(laneKeyPrefix + "laneAttributes.laneType.len"));
            lane.laneAttributes.laneType.u.vehicle.buf = buffer;
            lane.laneAttributes.directionalUse.len = std::stoi(keyValuePairs.at(laneKeyPrefix + "laneAttributes.directionalUse.len"));
            lane.laneAttributes.directionalUse.buf = buffer;
            lane.laneAttributes.sharedWith.len = std::stoi(keyValuePairs.at(laneKeyPrefix + "laneAttributes.sharedWith.len"));
            lane.laneAttributes.sharedWith.buf = buffer;
            lane.laneID = std::stoi(keyValuePairs.at(laneKeyPrefix + "laneID"));
            lane.maneuvers_option = true;
            lane.name_option = true;
            lane.name = EU_DescriptiveName();
            lane.name.buf = buffer;
            lane.name.len = std::stoi(keyValuePairs.at(laneKeyPrefix + "descriptiveName.len"));
            lane.overlays_option = false;
            lane.regional_option = false;

            lane.nodeList.choice = EU_NodeListXY_nodes;

            // Extract lane connections
            std::string connectionsKeyPrefix = laneKeyPrefix + "connections.";
            int connectionsCount = std::stoi(keyValuePairs.at(connectionsKeyPrefix + "laneConnections"));

            // for (int connectionIndex = 0; connectionIndex < connectionsCount; ++connectionIndex)
            // {
            //     std::string connectionKeyPrefix = connectionsKeyPrefix + std::to_string(connectionIndex) + ".";

            //     connection.connectionId = std::stoi(keyValuePairs.at(connectionKeyPrefix + "connectionId"));
            //     connection.remoteID = keyValuePairs.at(connectionKeyPrefix + "remoteID");
            //     connection.fromLane = keyValuePairs.at(connectionKeyPrefix + "fromLane");
            //     connection.toLane = keyValuePairs.at(connectionKeyPrefix + "toLane");
            //     connection.signal_id = keyValuePairs.at(connectionKeyPrefix + "signal_id");

            //     // Add maneuvers details in a separate loop
            //     std::string maneuversKeyPrefix = connectionKeyPrefix + "maneuvers.";
            //     int maneuversCount = std::stoi(keyValuePairs.at(maneuversKeyPrefix + "maneuversCount"));

            //     for (int maneuverIndex = 0; maneuverIndex < maneuversCount; ++maneuverIndex)
            //     {
            //         std::string maneuverKeyPrefix = maneuversKeyPrefix + std::to_string(maneuverIndex) + ".";
            //         std::string maneuver = keyValuePairs.at(maneuverKeyPrefix + "maneuver");
            //         connection.maneuvers.push_back(maneuver);
            //     }

            //     lane.connections.push_back(connection);
            // }

            // Iterate over the nodes for the current lane
            std::string nodeCountKey = laneKeyPrefix + "nodeList.u.nodes.count";
            int nodeCount = std::stoi(keyValuePairs.at(nodeCountKey));

            for (int nodeIndex = 0; nodeIndex < nodeCount; ++nodeIndex)
            {
                std::string nodeKeyPrefix = laneKeyPrefix + "nodeList.u.nodes[" + std::to_string(nodeIndex) + "].";

                node.attributes_option = false;
                node.delta.choice = EU_NodeOffsetPointXY_node_LatLon;
                node.delta.u.node_LatLon.lat = std::stod(keyValuePairs.at(nodeKeyPrefix + "delta.u.node_LatLon.lat"));
                node.delta.u.node_LatLon.lon = std::stod(keyValuePairs.at(nodeKeyPrefix + "delta.u.node_LatLon.lon"));

                // Add the node to the lane
                if (asn1_seq_add(asn1_type_EU_NodeXY,
                                 &lane.nodeList.u.nodes.count,
                                 (void **)(&lane.nodeList.u.nodes.tab),
                                 &node))
                {
                    printf("Unable to add seq\n");
                }
            }

            // Add the lane to the intersection
            if (asn1_seq_add(asn1_type_EU_GenericLane,
                             &intersection.laneSet.count,
                             (void **)(&intersection.laneSet.tab),
                             &lane))
            {
                printf("Unable to add seq\n");
            }
        }

        // Add the intersection to the IntersectionList
        if (asn1_seq_add(asn1_type_EU_IntersectionGeometry,
                         &map->intersections.count,
                         (void **)(&map->intersections.tab),
                         &intersection))
        {
            printf("Unable to add seq\n");
        }
    }
}

void MapWriter::create_and_send_a_map(const cms_session_t *session)
{
    parseJSONFile("ISD_11090_RSU#05_MAPEM_StringModified.json", keyValuePairs);
    bool error = false;
    ASN1Error decode_err = {0};
    EU_MAPEM mapem = {0};
    fill_map(&mapem, keyValuePairs);

    if (!error)
    {
        /* Encode to an allocated buffer */
        uint8_t *encode_buff = NULL;
        int encoded_length = asn1_uper_encode2(&encode_buff, asn1_type_EU_MAPEM, &mapem, &decode_err);
        if (encoded_length <= 0)
        {
            printf("Error in encode: %s\n", decode_err.msg);
            error = true;
        }
        else
        {

            cms_buffer_view_t msg = {
                .data = encode_buff,
                .length = encoded_length};
            /*Send as a WSMP message */
            error = send_as_geonet_message(session, msg);
        }
    }
}

/* Send a GeoNetworking message */
bool MapWriter::send_as_geonet_message(const cms_session_t *session, cms_buffer_view_t msg)
{
    cms_gn_send_data_t gnp_hdr = {0};
    fill_gnp_header(&gnp_hdr);

    int error = cms_gn_send(session, &gnp_hdr, msg, NULL);
    if (error)
    {
        printf("Unable to send GeoNet message\n");
    }
    else
    {
        printf("MAPem GeoNet message sent\n");
    }

    return error;
}

/* Fill GeoNetworking parameters */
void MapWriter::fill_gnp_header(cms_gn_send_data_t *header)
{
    /* Radio parameters */
    header->radio.datarate = CMS_DATARATE_NA;
    header->radio.expiry_time = 1000U;
    header->radio.interface_id = 1U;
    header->radio.sps_index = CMS_SPS_CHANNEL_INDEX_NA;
    header->radio.tx_power = 20;
    header->radio.user_prio = CMS_MAC_USER_PRIO_NA;

    /* GeoNet parameters - BTP for MAP */
    header->gn_params.btp_params.btp_port = 2003U;
    header->gn_params.btp_params.dest_port_info = 0U;

    /* GeoNet parameters - GeoNet header  */
    header->gn_params.gn_hdr.lifetime_ms = 60000U;
    header->gn_params.gn_hdr.max_hop_limit = 1;
    header->gn_params.gn_hdr.method = CMS_GN_SEND_METHOD_SHB;

    /* GeoNet parameters - GeoNet header  - Traffic class */
    header->gn_params.gn_hdr.traffic_class.chf_offl = CMS_GN_TRAFFIC_CLASS_CHF_OFFL_DISABLE;
    header->gn_params.gn_hdr.traffic_class.scf_en = CMS_GN_TRAFFIC_CLASS_SCF_DISABLE;
    header->gn_params.gn_hdr.traffic_class.tcid = 0U;

    /* Security info */
    header->security.sign_info.psid = 0U;
    header->security.sign_info.sign_method = CMS_SIGN_METH_NONE;
    header->security.sign_info.ssp.length = 0U;
    /* Keep header->security.ssp.ssp_field zeroed */
}
