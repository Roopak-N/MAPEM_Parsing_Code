#include "ItsRs4M.h"
#include "logger.h"
#include "writer.h"
#include "applications/map/src/MapWriter.h"
#include "string.h"
#include <boost/asio/io_context.hpp>
#include <boost/asio/signal_set.hpp>
#include <cms_v2x/api.h>
#include "ros/ros.h"
#include "std_msgs/String.h"
#include <iostream>

int main(int argc, char **argv)
{
        ItsRs4M::ItsRs4M ItsRs4M;
        ItsRs4M.initialize();
        ItsRs4M.connect();
        int messageType = 3; // CAM=0, CPM=1, Mapem = 2, both = CPM+MAPem (sends CPM according to ETSI rules and MAPem every 1s)
        ros::init(argc, argv, "listenerSdf");
        ros::NodeHandle nh;
        switch (messageType)
        {

        case 0:
        {
                printf("Running Cooperative Awareness Service in default \n");
                break;
        }
        case 1:
        {
                printf("Collective perception service activated \n");
                Writer w(ItsRs4M.getSession());
                ros::Subscriber twizzy = nh.subscribe("/ukf_ros_node/tracked_objects", 1000, &Writer::sensorDataFusionMast5, &w);
                ros::Subscriber local = nh.subscribe("/mast_5/fused_tracked_objects", 1000, &Writer::sensorDataFusionMast5, &w);
                ros::Subscriber global = nh.subscribe("/Global/DetectedObjects", 1000, &Writer::globalDataFusion, &w);
                ros::spin();
                w.stop();

                break;
        }
        case 2:
        {
                printf("MAPem service activated \n");
                MapWriter mw(ItsRs4M.getSession());
                printf("staring the timer for MAPem\n");
                mw.start();

                mw.stop();
                break;
        }
        case 3:
        {
                MapWriter mw(ItsRs4M.getSession());
                printf("staring the timer for MAPem\n");
                mw.start();
                Writer w(ItsRs4M.getSession());
                ros::Subscriber twizzy = nh.subscribe("/ukf_ros_node/tracked_objects", 1000, &Writer::sensorDataFusionMast5, &w);
                ros::Subscriber local = nh.subscribe("/mast_5/fused_tracked_objects", 1000, &Writer::sensorDataFusionMast5, &w);
                ros::Subscriber global = nh.subscribe("/Global/DetectedObjects", 1000, &Writer::globalDataFusion, &w);
                ros::spin();
                w.stop();
                mw.stop();
                break;

        }
               
}
}
