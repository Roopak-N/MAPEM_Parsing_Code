#include "periodic_timer.h"

PeriodicTimer::PeriodicTimer(boost::asio::io_context &ctx, uint interval_ms)
    : m_interval_ms(interval_ms), m_timer(ctx)
{
}

PeriodicTimer::~PeriodicTimer()
{
    stop();
}

void PeriodicTimer::start()
{
    m_timer.expires_after(std::chrono::milliseconds(m_interval_ms));
    m_timer.async_wait(std::bind(&PeriodicTimer::handleTimeout, this, std::placeholders::_1));
}

void PeriodicTimer::stop()
{
    m_timer.cancel();
}

void PeriodicTimer::handleTimeout(const boost::system::error_code &err)
{
    if (!err)
    {
        sig_timeout();
        m_timer.expires_after(std::chrono::milliseconds(m_interval_ms));
        m_timer.async_wait(std::bind(&PeriodicTimer::handleTimeout, this, std::placeholders::_1));
    }
}
