#ifndef ITS_RS4_M_H
#define ITS_RS4_M_H

#include <cms_v2x/api.h>
#include <cms_v2x/nav.h>
#include <string>
#include <vector>
#include <cms_v2x/gn.h>
#include <boost/signals2/signal.hpp>
#include <v2x/asn.1/v2x_eu_asn.h>
#include <v2x/asn.1/asn1defs.h>
#include <cms_v2x/gn.h>

namespace ItsRs4M
{
    class ItsRs4M
    {
    public:
        ItsRs4M();
        ~ItsRs4M();

        void initialize();
        void connect(const std::string &host = "192.168.1.54");
        cms_session_t getSession();

    private:
        cms_session_t m_session = cms_get_session();
        /* Get the latest position */
        cms_nav_fix_t nav_fix = {0};

        bool m_initialized = false;
        bool m_connected = false;
    };
} // namespace ItsRs4M

#endif // ITS_OB4_M_H
