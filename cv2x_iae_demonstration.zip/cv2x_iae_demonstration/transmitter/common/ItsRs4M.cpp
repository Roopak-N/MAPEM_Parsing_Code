#include "ItsRs4M.h"
#include "ItsRs4M_exception.h"
#include "logger.h"

ItsRs4M::ItsRs4M::ItsRs4M()
{
}

ItsRs4M::ItsRs4M::~ItsRs4M()
{
    bool error;
    cms_api_disconnect(&m_session);
    cms_api_clean();

    // return (int)error;
}

void ItsRs4M::ItsRs4M::initialize()
{
    Logger::logInfo("Initialize the ITS session");

    /* auto err = v2x_api_init();
     if (v2x_error(err))
         throw ItsRs4M_exception("Unable to initialize the unplugged ITS API", err);

     v2x_s_callbacks_t callbacks = V2X_S_CALLBACKS_INITIALIZER;

     err = v2x_register_aid(&m_session, 10ULL, &callbacks, this);
     if (v2x_error(err))
         throw ItsRs4M_exception("Unable to connecto to the device", err);
 */
    m_initialized = true;
    Logger::logInfo("The ITS session initialization was successful");
}

void ItsRs4M::ItsRs4M::connect(const std::string &host)
{
    if (!m_initialized)
        throw ItsRs4M_exception("The connection was not initialized successfully.");

    Logger::logInfo("Connect to the ITS remote server");

    auto err = cms_api_connect_easy(&m_session, host.c_str());
    if (err)
        throw ItsRs4M_exception("Unable to connecto to the device", err);

    err = cms_nav_get_last_fix(&m_session, NULL, &nav_fix);
    if (err)
        throw ItsRs4M_exception("Unable to obtain GPS fix", err);

    else
    {
        printf("Latitude angle: %ld\n", (long)nav_fix.latitude);
        printf("Longitudinal angle: %ld\n", (long)nav_fix.longitude);
    }

    m_connected = true;
    Logger::logInfo("The connection to the device was successful");
}

cms_session_t ItsRs4M::ItsRs4M::getSession()
{
    return m_session;
}
