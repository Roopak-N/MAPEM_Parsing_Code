#ifndef WRITER_H
#define WRITER_H

#include <cstdint>
#include <thread>
#include <cms_v2x/cpm.h>
#include <boost/asio/io_context.hpp>
#include <boost/asio/executor_work_guard.hpp>
#include <cms_v2x/api.h>
#include <cms_v2x/nav.h>
#include <cms_v2x/cam.h>
#include <cms_v2x/cpm.h>
#include <v2x/asn.1/v2x_eu_asn.h>
#include <v2x/asn.1/asn1defs.h>
#include <cms_v2x/gn.h>
#include "ItsRs4M.h"
#include "ItsRs4M_exception.h"
#include "twizzy/TrackedObject.h"
#include "twizzy/TrackedObjects.h"

#include "sdfmast5/TrackObject.h"
#include "sdfmast5/TrackObjectList.h"

#include "globaldatafusion/GlobalTrackObject.h"
#include "globaldatafusion/GlobalTrackObjectList.h"
#include "TimeCalculator.h"

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "string.h"
#include "taiClock.h"

class Writer
{
private:
    static int count;
    int number_of_sensors;
    int currentPdcIx;

public:
    Writer(cms_session_t m_session);

    ~Writer();

    void stop();

    std::thread *m_writerThread = nullptr;
    boost::asio::io_context m_ev;
    boost::asio::executor_work_guard<boost::asio::io_context::executor_type> m_workGuard;
    ros::Publisher cpm_pub_sent_status;
    // cms_session_t *m_session;
    cms_session_t m_session = cms_get_session();
    cms_nav_fix_t nav_fix = {0};
    bool error;

    /* Create payload */
    EU_CPM cpm = {0};
    ASN1Error decode_err = {0};
    EU_ObjectClassWithConfidence classification;

    /*Encode payload*/
    uint8_t *encode_buff = NULL;
    char err_buff[512];
    int err_buff_len = sizeof(err_buff);
    int encoded_length;
    int objid;
    uint32_t numberDetectedObjects;
    int maxNumberofObjects;
    int64_t lastGpsfix;
    void sensorDataFusionMast5(const transmitter::TrackObjectListConstPtr &msg);
    void globalDataFusion(const transmitter::GlobalTrackObjectListConstPtr &msg);
    int sdfTimestamp;

protected:
    V2XTimeStamps::TimeCalculator tc;
    void fill_cpm(EU_CPM *, cms_nav_fix_t, const transmitter::TrackObjectListConstPtr &msg);
    bool allocateSpaceForSensorInfo(EU_CPM *cpm, uint32_t infoNum);
    bool allocateSpaceForPerceptionData(EU_CPM *, uint32_t);
    bool allocateSpaceForPerceivedObjects(EU_CPM *, uint32_t, uint32_t);
    static void fill_gnp_header(cms_gn_send_data_t *);
    static bool send_as_geonet_message(const cms_session_t *session, cms_buffer_view_t msg);
};

#endif // WRITER_H
