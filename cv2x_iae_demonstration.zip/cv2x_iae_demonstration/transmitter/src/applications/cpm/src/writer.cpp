#include "writer.h"
#include "logger.h"
#include "periodic_timer.h"
#include <chrono>
using namespace std::chrono;

Writer::Writer(cms_session_t session)
    : m_workGuard(boost::asio::make_work_guard(m_ev)), m_session(session)
{
    numberDetectedObjects = 0;
    sdfTimestamp = 0;
    cms_nav_get_last_fix(&m_session, NULL, &nav_fix);
}

Writer::~Writer()
{
    stop();
}

void Writer::stop()
{
    /* Sleep for 1 second */
    /* Keep alive */
    for (;;)
    {
        (void)sleep(10);
    }
    if (m_writerThread)
    {
        m_workGuard.reset();
        m_ev.stop();
        m_writerThread->join();
        delete m_writerThread;
        m_writerThread = nullptr;
    }
}
/*Sensor information container (SIC)*/
bool Writer::allocateSpaceForSensorInfo(EU_CPM *cpm, uint32_t infoNum)
{

    currentPdcIx = 0;
    int sicIx = currentPdcIx;
    currentPdcIx++;
    printf("Allocating in SIC %d \n", currentPdcIx);
    EU_CpmPerceptionDataContainer_1 *cont = &cpm->cpm.cpmParameters.perceptionData.tab[sicIx];
    cont->containerId = EU_sensorInformationCpmContainer;
    cont->containerData.type = (ASN1CType *)(asn1_type_EU_SensorInformationContainer);

    cont->containerData.u.data = asn1_mallocz_value(asn1_type_EU_SensorInformationContainer);

    if (cont->containerData.u.data != NULL)
    {
        printf("SIC index value %d \n", sicIx);
        EU_SensorInformationContainer *sic = (EU_SensorInformationContainer *)(cpm->cpm.cpmParameters.perceptionData.tab[sicIx].containerData.u.data);

        sic->tab = (EU_SensorInformation *)(asn1_mallocz(infoNum * asn1_get_size(asn1_type_EU_SensorInformation)));

        if (sic->tab != NULL)
        {
            printf("Successfully allocated memory for sensor information\n");
            sic->count = infoNum;
            return true;
        }
        else
        {
            printf("Cannot allocate memory for sensor info container\n");
            return false;
        }
    }
}
bool Writer::allocateSpaceForPerceptionData(EU_CPM *cpm, uint32_t containerNum)
{

    cpm->cpm.cpmParameters.perceptionData_option = ASN1_TRUE;
    cpm->cpm.cpmParameters.perceptionData.count = containerNum;
    cpm->cpm.cpmParameters.perceptionData.tab = (EU_CpmPerceptionDataContainer_1 *)(asn1_mallocz(containerNum * asn1_get_size(asn1_type_EU_CpmPerceptionDataContainer_1)));

    bool res = (cpm->cpm.cpmParameters.perceptionData.tab != NULL);
    if (!res)
    {
        printf("Cannot allocate memory for perception data container");
    }

    return res;
}

bool Writer::allocateSpaceForPerceivedObjects(EU_CPM *cpm, uint32_t objectNum, uint32_t totalObjectNum)
{

    printf("Allocating in perceived object container \n");
    EU_CpmPerceptionDataContainer_1 *cont = cpm->cpm.cpmParameters.perceptionData.tab;

    cont->containerId = EU_perceivedObjectCpmContainer;
    cont->containerData.type = (ASN1CType *)(asn1_type_EU_PerceivedObjectContainer);

    cont->containerData.u.data = asn1_mallocz_value(asn1_type_EU_PerceivedObjectContainer);

    int pocIx = 0;

    bool res = (cont->containerData.u.data != NULL);

    if (res)
    {

        EU_PerceivedObjectContainer *poc = (EU_PerceivedObjectContainer *)(cpm->cpm.cpmParameters.perceptionData.tab[pocIx].containerData.u.data);

        poc->numberOfPerceivedObjects = totalObjectNum;
        poc->perceivedObjects.count = objectNum;

        poc->perceivedObjects.tab = (EU_PerceivedObject *)(asn1_mallocz(objectNum * asn1_get_size(asn1_type_EU_PerceivedObject)));

        res = (poc->perceivedObjects.tab != NULL);
        if (!res)
        {
            printf("Cannot allocate memory for perceived objects");
        }
    }
    else
    {
        printf("Cannot allocate memory for perceived object container");
    }

    return res;
}

// ROS msg subscription callback function
void Writer::sensorDataFusionMast5(const transmitter::TrackObjectListConstPtr &msg)
{

    /*  /*Retrieving fields of sensor data fusion*/
    ROS_INFO("Generating CPMs for Local tracked objects ...");
    fill_cpm(&cpm, nav_fix, msg);
    if (!asn1_check_constraints(asn1_type_EU_CPM, &cpm, err_buff, err_buff_len))
    {
        printf("Error in constraints: %s\n", err_buff);
        error = true;
    }
    else
    {
        printf("Constraints check passed\n");
    }

    encoded_length = asn1_uper_encode2(&encode_buff, asn1_type_EU_CPM, &cpm, &decode_err);
    if (encoded_length <= 0)
    {
        printf("Error in CPM encoding: %s, bit_pos: %d  line num: %d\n", decode_err.msg, decode_err.bit_pos, decode_err.line_num);
        error = true;
    }
    else
    {
        printf("Encoding CPM is successful!\n");
        printf("Encoded length: %d ", encoded_length);
        cms_buffer_view_t msg = {
            .data = encode_buff,
            .length = encoded_length};
        /* Send as a GeoNetworking message */
        error = send_as_geonet_message(&m_session, msg);
    }
}

void Writer::globalDataFusion(const transmitter::GlobalTrackObjectListConstPtr &msg)
{
    /*
     ROS_INFO("Generating CPMs for Global tracked objects ...");
     fill_cpm(&cpm, nav_fix, msg);
     if(!asn1_check_constraints(asn1_type_EU_CPM, &cpm, err_buff, err_buff_len)) {
         printf("Error in constraints: %s\n", err_buff);
         error = true;
     } else {
         printf("Constraints check passed\n");
     }

     encoded_length = asn1_uper_encode2(&encode_buff, asn1_type_EU_CPM, &cpm, &decode_err);
     if(encoded_length <= 0) {
         printf("Error in CPM encoding: %s, bit_pos: %d  line num: %d\n", decode_err.msg, decode_err.bit_pos, decode_err.line_num);
         error = true;
     } else {
         printf("Encoding CPM is successful!\n");
         printf ("Encoded length: %d ", encoded_length);
         cms_buffer_view_t msg = {
                 .data = encode_buff,
                 .length = encoded_length
         };

         error = send_as_geonet_message(&m_session, msg);
     } */
}

// Fill the contents of CPM
void Writer::Writer::fill_cpm(EU_CPM *cpm, cms_nav_fix_t nav_fix, const transmitter::TrackObjectListConstPtr &msg)
{
    /*fill ITS PDU header*/
    cpm->header.messageID = 14;
    cpm->header.protocolVersion = 1;
    cpm->header.stationID = 1140554438; // Convert to decimal and transmit (Commsignia GUI gives as Hex)

    // Generation delta time

    // Commsignia converts GNSS time to UTC time since Unix epoch and provides in milliseconds. It is then casted into chrono::milliseconds.
    // We compute the number of milliseconds between current time stamp and ISO time stamp reference (ETSI time stamp reference).
    auto tp_gnss = std::chrono::milliseconds(nav_fix.timestamp - 1072915200000);
    int genDelta = tp_gnss.count() % 65536;
    cpm->cpm.generationDeltaTime = genDelta;

    printf("Current reference position from GPS source (converted to UTC) %lu \n", nav_fix.timestamp);
    printf("Generation delta time: %d \n", cpm->cpm.generationDeltaTime);

    /*Fill the CPM parts, e.g.*/
    printf("----Management container---- \n");
    printf("Latitude: %u \n", nav_fix.latitude);
    printf("Longitude: %u \n", nav_fix.longitude);

    // Management container
    cpm->cpm.cpmParameters.managementContainer.stationType = EU_StationType_roadSideUnit; // For RSU=15, vehicle (passenger car)=5
    cpm->cpm.cpmParameters.managementContainer.referencePosition.latitude = nav_fix.latitude;
    cpm->cpm.cpmParameters.managementContainer.referencePosition.longitude = nav_fix.longitude;
    cpm->cpm.cpmParameters.managementContainer.messageSegmentInfo_option = false;

    // Station Data container
    cpm->cpm.cpmParameters.stationDataContainer_option = false;

    // Perceived object container
    numberDetectedObjects = msg->total_objects;
    cpm->cpm.cpmParameters.perceptionData_option = true;

    allocateSpaceForPerceptionData(cpm, 2);
    allocateSpaceForPerceivedObjects(cpm, numberDetectedObjects, maxNumberofObjects);
    EU_PerceivedObjectContainer *cont = ((EU_PerceivedObjectContainer *)
                                             cpm->cpm.cpmParameters.perceptionData.tab->containerData.u.data);
    cont->numberOfPerceivedObjects = numberDetectedObjects;
    // allocateSpaceForSensorInfo(cpm, 1);
    printf("Number of tracked objects by local sensor data fusion: %d \n", numberDetectedObjects);

    // Commsignia stack allows maximum of 10 objects to be sent in one POC (ETSI standards allows 128)
    maxNumberofObjects = 10;

    for (int i = 0; i < numberDetectedObjects; i++)
    {
        printf("Filling object: %d \n", i);
        sdfTimestamp = msg->header.stamp.nsec;
        auto tp_sdf = std::chrono::milliseconds(sdfTimestamp);
        int genDeltaSdf = tp_sdf.count();
        int timeOfMeasurement = (genDelta - genDeltaSdf) % 1500;   // According to ETSI it should be between 1500 to 1500.
        int objectAge = (tp_gnss.count() - tp_sdf.count()) % 1500; // NOW - last tracking time of object by sensor data fusion

        //printf("SDF timestamp %d \n", tp_sdf);
        //printf("SDF genDelta  %d \n", genDeltaSdf);
        //printf("time of measurement %d \n", timeOfMeasurement);
        //printf("Object age %d \n ", objectAge);

        /* The attributes of the struct "EU_PerceivedObject" in v2x_eu_asn.h are to be filled using the fields from
        "transmitter::TrackObjectListConstPtr& msg" from the "sensor data fusion" algorithm running on mast 5*/
        EU_PerceivedObject *object = &cont->perceivedObjects.tab[i];

        //printf("SDF time of measurement %f \n", msg->header.stamp.nsec); // removed from ROS topic
        // const auto tai_since_epoch_sdf = std::chrono::duration_cast<std::chrono::milliseconds>(tai_now_sdf.time_since_epoch());
        // int sdf_tai = tai_since_epoch_sdf.count() % 65535;

        object->objectID = msg->object_list[i].tracking_id;
        // object->timeOfMeasurement = cpm->cpm.generationDeltaTime - sdf_tai ;
        // printf("Object time of measurement %d \n",object->timeOfMeasurement);

        object->objectConfidence = (msg->object_list[i].obj_det_confidence) * 100; // Multiply by 100 to get the percentage (int)
        printf("Object ID %d \n", msg->object_list[i].tracking_id);
        printf("Object confidence %f \n", msg->object_list[i].obj_det_confidence); // value comes as zero or 1

        // Velocity of object - confidence values bot provided by sensor team. He we set default as 95.
        object->xSpeed.confidence = 95;
        object->xSpeed.value = msg->object_list[i].vx;
        object->ySpeed.confidence = 95;
        object->ySpeed.value = msg->object_list[i].vy;
        object->zSpeed_option = false;

        printf("Object xSpeed value %f \n", msg->object_list[i].vx);
        printf("Object ySpeed value %f \n", msg->object_list[i].vy);
        
        // Acceleration of object - currently not provided by sensor data fusion
        object->xAcceleration_option = false;
        object->yAcceleration_option = false;
        object->zAcceleration_option = false;

        // Distance of the object from reference point of measurement (here mast 5)
        // Distance of the object from reference point of measurement (here mast 5,11).
        object->objectRefPoint = EU_ObjectRefPoint_bottomMid;
        object->xDistance.confidence = 95;
        object->xDistance.value = abs(msg->object_list[i].obj_pose_x) * 100;
        object->zDistance_option = false;
        object->yDistance.confidence = 95;
        object->yDistance.value = abs(msg->object_list[i].obj_pose_y) * 100;
        printf("Object xDistance value %d \n", object->xDistance.value);
        printf("Object yDistance value %d \n", object->yDistance.value);

        // Object age
        object->objectAge_option = true;
        object->objectAge = objectAge;
        // object->objectAge - To be calculated

        // Object classification

        object->classification_option = true;
        object->classification.count = 0;

        classification.confidence = msg->object_list[i].obj_class_confidence;
        classification.objectClass.choice = EU_ObjectClass_vehicleSubclass;
        classification.objectClass.u.vehicleSubclass = EU_VehicleSubclassType_unknown;

        /* Add classification information*/

        if (asn1_seq_add(asn1_type_EU_ObjectClassWithConfidence,
                         &object->classification.count,
                         (void **)(&object->classification.tab),
                         &classification))
        {
            printf("Unable to add seq\n");
        }
        else
        {
            printf("Object classification information was successfully added!\n");
        }
        /*----yaw angle set as not available*/
        /*Note: the SDF provides it as a float64 datatype in units radians. If this values needs to be transmitted as int, some wrapping around is required.
        Currently we set yawAngle default value = 3601 according to ETSI TR 103562*/
        object->yawAngle_option = true;
        object->yawAngle.confidence = 95;
        object->yawAngle.value = 3601;

        // Object dimension - currently not provided by sensor data fusion
        object->planarObjectDimension1_option = false;
        object->planarObjectDimension2_option = false;
        object->verticalObjectDimension_option = false;

        object->dynamicStatus_option = false;
        object->matchedPosition_option = false;
        object->sensorIDList_option = false;
    }
    // Current implementation of SIC in commsignia re-uses perceptionData container. It has some concerns with implementation, hence we do not transmit SIC.
    /*     EU_SensorInformationContainer* sic_cont = ((EU_SensorInformationContainer*)
                    cpm->cpm.cpmParameters.perceptionData.tab[0].containerData.u.data);
        EU_SensorInformation* sensor_info = &sic_cont->tab[0];
        sensor_info->type=EU_SensorType_fusion;

        sensor_info->detectionArea.choice = EU_DetectionArea_stationarySensorCircular;
        sensor_info->detectionArea.u.stationarySensorCircular.nodeCenterPoint_option = false;
        sensor_info->detectionArea.u.stationarySensorCircular.radius = EU_Radius_oneMeter;
        sensor_info->freeSpaceConfidence_option = false;
        sensor_info->sensorID = 1;

        if (numberDetectedObjects == 0)
        {
            // Send CPMs every 1s with station & management data
            printf("No objects detected \n");
        } */
}

/* Fill Radio & GeoNetworking parameters */
void Writer::fill_gnp_header(cms_gn_send_data_t *header)
{
    /* Radio parameters */
    header->radio.datarate = CMS_DATARATE_NA;
    header->radio.expiry_time = 1000U;
    header->radio.interface_id = 1U;
    header->radio.sps_index = CMS_SPS_CHANNEL_INDEX_NA;
    header->radio.tx_power = 20;
    header->radio.user_prio = CMS_MAC_USER_PRIO_NA;

    /* GeoNet parameters - BTP for CPM */
    header->gn_params.btp_params.btp_port = 2009U;
    header->gn_params.btp_params.dest_port_info = 0U;

    /* GeoNet parameters - GeoNet header  */
    header->gn_params.gn_hdr.lifetime_ms = 60000U;
    header->gn_params.gn_hdr.max_hop_limit = 1;
    header->gn_params.gn_hdr.method = CMS_GN_SEND_METHOD_SHB;

    /* GeoNet parameters - GeoNet header  - Traffic class */
    header->gn_params.gn_hdr.traffic_class.chf_offl = CMS_GN_TRAFFIC_CLASS_CHF_OFFL_DISABLE;
    header->gn_params.gn_hdr.traffic_class.scf_en = CMS_GN_TRAFFIC_CLASS_SCF_DISABLE;
    header->gn_params.gn_hdr.traffic_class.tcid = 0U;

    /* Security info */
    header->security.sign_info.psid = 0U;
    header->security.sign_info.sign_method = CMS_SIGN_METH_NONE;
    header->security.sign_info.ssp.length = 0U;
    /* Keep header->security.ssp.ssp_field zeroed */
}

/* Send a GeoNetworking message */
bool Writer::send_as_geonet_message(const cms_session_t *session, cms_buffer_view_t msg)
{
    cms_gn_send_data_t gnp_hdr = {0};
    fill_gnp_header(&gnp_hdr);

    bool error = cms_gn_send(session, &gnp_hdr, msg, NULL);
    if (error)
    {
        printf("Unable to send GeoNet message\n");
    }
    else
    {
        printf("GeoNet message sent\n");
    }
    return error;
}
