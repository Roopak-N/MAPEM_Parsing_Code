#include "MapWriter.h"
#include "logger.h"
#include "periodic_timer.h"
#include <chrono>
using namespace std::chrono;

MapWriter::MapWriter(cms_session_t session)
    : m_workGuard(boost::asio::make_work_guard(m_ev)), m_session(session)
{
    cms_nav_get_last_fix(&m_session, NULL, &nav_fix);
}

MapWriter::~MapWriter()
{
    stop();
}

void MapWriter::MapWriter::start()
{
    if (m_MapWriterThread)
    {
        return;
    }
    m_MapWriterThread = new std::thread([this]()
                                        {
        PeriodicTimer timer(m_ev, 1000);
        timer.start();
        timer.sig_timeout.connect([this]() {
            printf("MapWriter::start");
           create_and_send_a_map(& m_session);      
        
        });

        m_ev.run(); });
}

void MapWriter::MapWriter::stop()
{
    /* Sleep for 1 second */
    /* Keep alive */
    for (;;)
    {
        (void)sleep(10);
    }
    if (m_MapWriterThread)
    {
        m_workGuard.reset();
        m_ev.stop();
        m_MapWriterThread->join();
        delete m_MapWriterThread;
        m_MapWriterThread = nullptr;
    }
}

// Parsing json
void MapWriter::MapWriter::parseJSON(const json &data, std::map<std::string, std::string> &keyValuePairs, const std::string &prefix = "")
{
    if (data.is_object())
    {
        for (auto it = data.begin(); it != data.end(); ++it)
        {
            // Generate the key by appending the current level's key to the prefix
            std::string key = prefix.empty() ? it.key() : prefix + "." + it.key();

            // Recursively call the function for nested objects or arrays
            if (it.value().is_object() || it.value().is_array())
            {
                parseJSON(it.value(), keyValuePairs, key);
            }
            else
            {
                // Store the key-value pair in the map
                keyValuePairs[key] = it.value().dump();
            }
        }
    }
    else if (data.is_array())
    {
        for (size_t i = 0; i < data.size(); ++i)
        {
            std::string key = prefix + "[" + std::to_string(i) + "]";

            if (data[i].is_object() || data[i].is_array())
            {
                parseJSON(data[i], keyValuePairs, key);
            }
            else
            {
                keyValuePairs[key] = data[i].dump();
            }
        }
    }
}

void MapWriter::MapWriter::parseJSONFile(const std::string &filename, std::map<std::string, std::string> &keyValuePairs)
{

    std::ifstream file(filename);
    if (file)
    {
        std::cout << "File exists in the given path" << std::endl;
    }
    else
    {
        std::cout << "File NOT found in the given path" << std::endl;
    }

    if (!file.is_open())
    {
        std::cout << "Failed to open the JSON file." << filename << std::endl;
        return;
    }

    try
    {
        json jsonData;
        file >> jsonData;

        parseJSON(jsonData, keyValuePairs);
    }

    catch (const json::exception &e)
    {
        std::cout << "Error while parsing JSON: " << e.what() << std::endl;
    }

    file.close();
}

// Fill the contents of CPM

void MapWriter::MapWriter::fill_map(EU_MAP *mapem)
{
    printf("Filling the contents of MAPem \n");

    // Parse Json file from group 2
    // give the absolute path here
    //RSU 11
    //parseJSONFile("/home/ettusb2101/Workspace/cv2x_in2lab/transmitter/src/applications/map/resources/mast11/geodatafiles/ISD_9705_RSU#11_MAPEM.json", keyValuePairs);
    //RSU 5
    parseJSONFile("ISD_9705_RSU#11_MAPEM_StringModified.json", keyValuePairs);
    EU_ItsPduHeader *header = &mapem->header;
    header->protocolVersion = 2;
    header->messageID = 5;
    header->stationID = 2;
    EU_MapData *map = &mapem->map;

    map->dataParameters_option = false;

    map->layerID_option = true;
    map->layerID = std::stoi(keyValuePairs.at("mapData.intersectionGeometry.referencePoint.layerID"));

    map->layerType_option = true;
   
    map->restrictionList_option = false;

    map->timeStamp_option = true;
    map->timeStamp = std::stoi(keyValuePairs.at("mapData.minuteOfTheYear"));
    map->roadSegments_option = false;
    map->msgIssueRevision = false;

    map->intersections_option = true;
    map->intersections.count = 0;
    uint8_t buffer[1] = {0x00};

     EU_IntersectionGeometry intersection = {0};
    intersection.id.id = std::stoi(keyValuePairs.at("mapData.intersectionGeometry.referencePoint.intersectionID"));
    printf("Intersection ID %d \n", intersection.id.id);
    intersection.speedLimits_option = false;
    
    intersection.id.region_option = false;
    intersection.laneWidth_option = true;
    
    intersection.laneWidth = std::stoi(keyValuePairs.at("mapData.intersectionGeometry.referencePoint.masterLaneWidth"));
    intersection.name_option = true;
    intersection.name_option = false; // need to convert from std::string to ASN1String data type
    intersection.preemptPriorityData_option = false;
    intersection.regional_option = false;
    intersection.revision = 1;    

    /* Add reference point */
    
    intersection.refPoint.lat = std::stoi(keyValuePairs.at("mapData.intersectionGeometry.referencePoint.referenceLat"));
    intersection.refPoint.Long = std::stoi(keyValuePairs.at("mapData.intersectionGeometry.referencePoint.referenceLon"));
    intersection.refPoint.elevation_option = true;
    intersection.refPoint.elevation = std::stoi(keyValuePairs.at("mapData.intersectionGeometry.referencePoint.referenceElevation"));
    intersection.refPoint.regional_option = false;
    

    /* Create an ingress lane */
    /* Create an ingress lane */
    EU_GenericLane lane = {0};
    lane.connectsTo_option = false;
    lane.egressApproach_option = false;
    lane.ingressApproach_option = true;
    lane.ingressApproach = 1;
    lane.laneAttributes.regional_option = false;
    lane.laneAttributes.laneType.choice =  EU_LaneTypeAttributes_vehicle;
    lane.laneAttributes.laneType.u.vehicle.len = 2;
    lane.laneAttributes.laneType.u.vehicle.buf = buffer;
    lane.laneAttributes.directionalUse.len = 2;
    lane.laneAttributes.directionalUse.buf = buffer;
    lane.laneAttributes.sharedWith.len = 10;
    lane.laneAttributes.sharedWith.buf = buffer;
    lane.laneID = 1;
    lane.maneuvers_option = false;
    lane.name_option = false;
    lane.overlays_option = false;
    lane.regional_option = false;
    lane.nodeList.choice =  EU_NodeListXY_nodes;
    lane.nodeList.u.nodes.count = 0;


    /* Create nodes */ 
    EU_NodeXY node1 = {};
    node1.attributes_option = false;
    node1.delta.choice = EU_NodeOffsetPointXY_node_LatLon;
    node1.delta.u.node_LatLon.lat = LANE_WEST_INGRESS_START_LAT;
    node1.delta.u.node_LatLon.lon = LANE_WEST_INGRESS_START_LON;

    EU_NodeXY node2 = {};
    node2.attributes_option = false;
    node2.delta.choice = EU_NodeOffsetPointXY_node_LatLon;
    node2.delta.u.node_LatLon.lat = LANE_WEST_INGRESS_END_LAT;
    node2.delta.u.node_LatLon.lon = LANE_WEST_INGRESS_END_LON;

    /*Add nodes to lane*/
    if(asn1_seq_add(asn1_type_EU_NodeXY,
                    &lane.nodeList.u.nodes.count,
                    (void**)(&lane.nodeList.u.nodes.tab),
                    &node1)) {
        printf("Unable to add seq\n");
    };
    
    if(asn1_seq_add(asn1_type_EU_NodeXY,
                    &lane.nodeList.u.nodes.count,
                    (void**)(&lane.nodeList.u.nodes.tab),
                    &node2)) {
        printf("Unable to add seq\n");
    };

    /*Add lane to intersection*/
     if(asn1_seq_add(asn1_type_EU_GenericLane,
                    &intersection.laneSet.count,
                    (void**)(&intersection.laneSet.tab),
                    &lane)) {
        printf("Unable to add seq\n");
    };

    /*Add intersection to IntersectionList */
    if(asn1_seq_add(asn1_type_EU_IntersectionGeometry,
                    &map->intersections.count,
                    (void**)(&map->intersections.tab),
                    &intersection)) {
        printf("Unable to add seq\n");
    };
    
}

void MapWriter::MapWriter::create_and_send_a_map(const cms_session_t *session)
{
    // parseJSONFile("ISD_9705_RSU#11_MAPEM.json", keyValuePairs);
    bool error = false;
    ASN1Error decode_err = {0};
    EU_MAPEM mapem = {0};
    fill_map(&mapem);

    if (!error)
    {
        /* Encode to an allocated buffer */
        uint8_t *encode_buff = NULL;
        
        int encoded_length = asn1_uper_encode2(&encode_buff, asn1_type_EU_MAPEM, &mapem, &decode_err);
        printf("Encoded length %d \n", encoded_length);
        if (encoded_length <= 0)
        {
            printf("Error in encode: %s\n", decode_err.msg);
            error = true;
        }
        else
        {

            cms_buffer_view_t msg = {
                .data = encode_buff,
                .length = encoded_length};
            /*Send as a WSMP message */
            error = send_as_geonet_message(session, msg);
        }
    }
}

/* Send a GeoNetworking message */
bool MapWriter::MapWriter::send_as_geonet_message(const cms_session_t *session, cms_buffer_view_t msg)
{
    cms_gn_send_data_t gnp_hdr = {0};
    fill_gnp_header(&gnp_hdr);

    int error = cms_gn_send(session, &gnp_hdr, msg, NULL);
    if (error)
    {
        printf("Unable to send GeoNet message\n");
    }
    else
    {
        printf("MAPem GeoNet message sent\n");
    }

    return error;
}

/* Fill GeoNetworking parameters */
void MapWriter::MapWriter::fill_gnp_header(cms_gn_send_data_t *header)
{
    /* Radio parameters */
    header->radio.datarate = CMS_DATARATE_NA;
    header->radio.expiry_time = 1000U;
    header->radio.interface_id = 1U;
    header->radio.sps_index = CMS_SPS_CHANNEL_INDEX_NA;
    header->radio.tx_power = 20;
    header->radio.user_prio = CMS_MAC_USER_PRIO_NA;

    /* GeoNet parameters - BTP for MAP */
    header->gn_params.btp_params.btp_port = 2003U;
    header->gn_params.btp_params.dest_port_info = 0U;

    /* GeoNet parameters - GeoNet header  */
    header->gn_params.gn_hdr.lifetime_ms = 60000U;
    header->gn_params.gn_hdr.max_hop_limit = 1;
    header->gn_params.gn_hdr.method = CMS_GN_SEND_METHOD_SHB;

    /* GeoNet parameters - GeoNet header  - Traffic class */
    header->gn_params.gn_hdr.traffic_class.chf_offl = CMS_GN_TRAFFIC_CLASS_CHF_OFFL_DISABLE;
    header->gn_params.gn_hdr.traffic_class.scf_en = CMS_GN_TRAFFIC_CLASS_SCF_DISABLE;
    header->gn_params.gn_hdr.traffic_class.tcid = 0U;

    /* Security info */
    header->security.sign_info.psid = 0U;
    header->security.sign_info.sign_method = CMS_SIGN_METH_NONE;
    header->security.sign_info.ssp.length = 0U;
    /* Keep header->security.ssp.ssp_field zeroed */
}