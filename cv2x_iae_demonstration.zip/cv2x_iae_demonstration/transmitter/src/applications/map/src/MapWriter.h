#ifndef MapWriter_H
#define MapWriter_H

#include <cstdint>
#include <thread>
#include <cms_v2x/cpm.h>
#include <boost/asio/io_context.hpp>
#include <boost/asio/executor_work_guard.hpp>
#include <cms_v2x/api.h>
#include <cms_v2x/nav.h>
#include <cms_v2x/cam.h>
#include <cms_v2x/cpm.h>
#include <v2x/asn.1/v2x_eu_asn.h>
#include <v2x/asn.1/asn1defs.h>
#include <cms_v2x/gn.h>
#include "ItsRs4M.h"
#include "ItsRs4M_exception.h"
#include "string.h"
#include <nlohmann/json.hpp>
#include<iostream>
#include <fstream> 

using namespace std::chrono;
using json = nlohmann::json;

#define LANE_WEST_INGRESS_START_LAT 389169770
#define LANE_WEST_INGRESS_START_LON -770122820
#define LANE_WEST_INGRESS_END_LAT 389169810
#define LANE_WEST_INGRESS_END_LON -770126280

class MapWriter
{
private:
 std::map<std::string, std::string> keyValuePairs;
public:
  MapWriter(cms_session_t m_session);
  EU_IntersectionGeometry intersection = {0};
  EU_Position3D refPoint = {0};
  EU_GenericLane lane = {0};
  EU_Connection connection = {};
  //std::map<std::string, std::string> keyValuePairs;
  ~MapWriter();
  void start();
  void stop();

  std::thread *m_MapWriterThread = nullptr;
  boost::asio::io_context m_ev;
  boost::asio::executor_work_guard<boost::asio::io_context::executor_type> m_workGuard;

  // cms_session_t *m_session;
  cms_session_t m_session = cms_get_session();
  cms_nav_fix_t nav_fix = {0};

  /* Create payload */
  EU_MAPEM mapem = {0};

  /*Encode payload*/
  uint8_t *encode_buff = NULL;
  

  int64_t lastGpsfix;


protected:
  void fill_map(EU_MAP* );
  void create_and_send_a_map(const cms_session_t *session);
  void parseJSON(const json& , std::map<std::string, std::string>& , const std::string& );
  void parseJSONFile(const std::string& , std::map<std::string, std::string>& );
  void fill_gnp_header(cms_gn_send_data_t *header);
  bool send_as_geonet_message(const cms_session_t *session, cms_buffer_view_t msg);
};

#endif // MapWriter_H