#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

// Recursive function to parse nested JSON structure
void parseJSON(const json& data, std::map<std::string, std::string>& keyValuePairs, const std::string& prefix = "")
{
    if (data.is_object()) {
        for (auto it = data.begin(); it != data.end(); ++it) {
            // Generate the key by appending the current level's key to the prefix
            std::string key = prefix.empty() ? it.key() : prefix + "." + it.key();

            // Recursively call the function for nested objects or arrays
            if (it.value().is_object() || it.value().is_array()) {
                parseJSON(it.value(), keyValuePairs, key);
            }
            else {
                // Store the key-value pair in the map
                keyValuePairs[key] = it.value().dump();
            }
        }
    }
    else if (data.is_array()) {
        for (size_t i = 0; i < data.size(); ++i) {
            std::string key = prefix + "[" + std::to_string(i) + "]";

            if (data[i].is_object() || data[i].is_array()) {
                parseJSON(data[i], keyValuePairs, key);
            }
            else {
                keyValuePairs[key] = data[i].dump();
            }
        }
    }
}

// Parse the JSON file and store key-value pairs
void parseJSONFile(const std::string& filename, std::map<std::string, std::string>& keyValuePairs)
{
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cout << "Failed to open the JSON file." << std::endl;
        return;
    }

    try {
        json jsonData;
        file >> jsonData;

         parseJSON(jsonData, keyValuePairs);
    }

    catch (const json::exception& e) {
        std::cout << "Error while parsing JSON: " << e.what() << std::endl;
    }

    file.close();
}

int main()
{
    std::map<std::string, std::string> keyValuePairs;
    parseJSONFile("ISD_2648_RSU#01_MAPEM.json", keyValuePairs);

    // Access the parsed key-value pairs
    for (const auto& pair : keyValuePairs) {
        std::cout << pair.first << ": " << pair.second << std::endl;
    }

    return 0;
}
